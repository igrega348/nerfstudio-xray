from typing import Dict, Literal

import torch
from nerfstudio.data.datasets.base_dataset import (
    InputDataset, get_image_mask_tensor_from_path)


class TemplateDataset(InputDataset):
   pass